//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var a,b,c:Int
a = 1000
b = 800
c = 1800
c = a + b
if a>b{
    print("a is > b")}
else {
    print("b is >a")}


for i in 1...10
{
    print (i)
    for i in 1..<10
{
    print (i)
    
}
}


    
for i in stride (from:0,to: 50,by: 5)
   
    {
        print (i)
        
var g=1
while(g<=10)
{
    print(i)
    g = g+1
    
}
}

var y = (10,20)
print (y.0,y.1)





